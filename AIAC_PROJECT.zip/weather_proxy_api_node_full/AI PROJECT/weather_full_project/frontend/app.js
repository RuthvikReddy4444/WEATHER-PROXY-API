// frontend/app.js
(() => {
  const API_BASE = (new URLSearchParams(window.location.search).get('api')) || 'http://localhost:3001';
  const q = s => document.querySelector(s);

  const state = {
    city: '',
    data: null
  };

  const el = {
    form: q('#searchForm'),
    input: q('#cityInput'),
    msg: q('#message'),
    city: q('#city'),
    desc: q('#desc'),
    temp: q('#temp'),
    feels: q('#feels'),
    minmax: q('#minmax'),
    humidity: q('#humidity'),
    wind: q('#wind'),
    pressure: q('#pressure'),
    visibility: q('#visibility'),
    clouds: q('#clouds'),
    icon: q('#icon'),
    localTime: q('#localTime'),
    sunrise: q('#sunrise'),
    sunset: q('#sunset'),
    card: q('#card'),
    locBtn: q('#locBtn'),
    suggestions: q('#suggestions'),
    weatherPanel: q('#weatherPanel')
  };

  function showMessage(txt) {
    el.msg.textContent = txt || '';
  }

  function unixToTime(unix, tzOffsetSeconds) {
    if (!unix) return '--';
    const d = new Date((unix + (tzOffsetSeconds || 0)) * 1000);
    return d.toUTCString().replace('GMT', '').split(' ')[4]; // HH:MM:SS
  }

  function setBackground(weatherMain) {
    // simple backgrounds by weather main
    const body = document.body;
    if (!weatherMain) {
      body.style.background = 'linear-gradient(180deg,#0b1220,#071226)';
      return;
    }
    const m = weatherMain.toLowerCase();
    if (m.includes('cloud')) body.style.background = 'linear-gradient(180deg,#2b3a4a,#0b1220)';
    else if (m.includes('rain') || m.includes('drizzle')) body.style.background = 'linear-gradient(180deg,#1f2b36,#061021)';
    else if (m.includes('snow')) body.style.background = 'linear-gradient(180deg,#2b3b4a,#102033)';
    else if (m.includes('clear')) body.style.background = 'linear-gradient(180deg,#f6d365,#fda085)';
    else body.style.background = 'linear-gradient(180deg,#0b1220,#071226)';
  }

  function mapIconToUrl(iconCode) {
    if (!iconCode) return '';
    // OpenWeather icon URL
    return `https://openweathermap.org/img/wn/${iconCode}@4x.png`;
  }

  function safe(n, digits=1) {
    if (n === undefined || n === null) return '--';
    return (Math.round(n * (10**digits)) / (10**digits)).toString();
  }

  function render(data) {
    if (!data) {
      el.city.textContent = '—';
      el.desc.textContent = '';
      el.temp.textContent = '--';
      return;
    }
    // set background
    setBackground(data.weather || data.weather_main || '');

    el.city.textContent = data.city + (data.country ? ', ' + data.country : '');
    el.desc.textContent = (data.weather || '').toLowerCase();
    el.temp.innerHTML = (data.temperature_celsius !== undefined ? safe(data.temperature_celsius, 2) : '--') + '°C';
    el.feels.textContent = (data.feels_like !== undefined ? safe(data.feels_like,1)+' °C' : '--');
    el.minmax.textContent = (data.temp_min !== undefined ? safe(data.temp_min,1) : '--') + ' / ' + (data.temp_max !== undefined ? safe(data.temp_max,1) : '--');
    el.humidity.textContent = (data.humidity !== undefined ? data.humidity : '--');
    el.wind.textContent = (data.wind_speed !== undefined ? data.wind_speed : '--');
    el.pressure.textContent = (data.pressure !== undefined ? data.pressure : '--');
    el.visibility.textContent = (data.visibility !== undefined ? data.visibility : '--');
    el.clouds.textContent = (data.clouds !== undefined ? data.clouds : '--');

    // icon
    const url = mapIconToUrl(data.icon);
    if (url) {
      el.icon.src = url;
      el.icon.style.display = 'block';
    } else {
      el.icon.style.display = 'none';
    }

    // local time: compute from timezone offset (seconds)
    if (data.timezone !== undefined) {
      const tz = data.timezone;
      const d = new Date(Date.now() + tz*1000); // not perfect but okay for display
      el.localTime.textContent = `Local time: ${d.toUTCString().replace('GMT','').split(' ')[4]}`;
    } else {
      el.localTime.textContent = '';
    }

    el.sunrise.textContent = unixToTime(data.sunrise, data.timezone);
    el.sunset.textContent = unixToTime(data.sunset, data.timezone);

    showMessage('');
  }

  async function fetchWeather(city) {
    showMessage('Loading...');
    try {
      const res = await fetch(`${API_BASE}/weather?city=${encodeURIComponent(city)}`);
      const json = await res.json();
      if (!res.ok) throw new Error(json.error || res.statusText || 'Error');

      // expected backend fields (but handle gracefully)
      // map backend structure to front-end expected keys
      const payload = {
        city: json.city || json.name || city,
        country: json.country || json.sys?.country || '',
        temperature_celsius: json.temperature_celsius ?? json.main?.temp ?? null,
        feels_like: json.feels_like ?? json.main?.feels_like ?? null,
        temp_min: json.temp_min ?? json.main?.temp_min ?? null,
        temp_max: json.temp_max ?? json.main?.temp_max ?? null,
        humidity: json.humidity ?? json.main?.humidity ?? null,
        wind_speed: json.wind_speed ?? json.wind?.speed ?? null,
        pressure: json.pressure ?? json.main?.pressure ?? null,
        visibility: json.visibility ?? json.visibility ?? null,
        clouds: json.clouds ?? json.clouds?.all ?? null,
        weather: (json.weather ?? json.weather_description ?? (json.weather[0]?.description ?? '') ) || json.weather_description || '',
        icon: json.icon ?? (json.weather && json.weather[0] && json.weather[0].icon) ?? null,
        sunrise: json.sunrise ?? json.sys?.sunrise ?? null,
        sunset: json.sunset ?? json.sys?.sunset ?? null,
        timezone: json.timezone ?? json.timezone ?? 0
      };

      state.data = payload;
      render(payload);
    } catch (err) {
      showMessage('Error: ' + err.message);
      console.error(err);
    }
  }

  // Event handlers
  el.form.addEventListener('submit', e => {
    e.preventDefault();
    const c = el.input.value.trim();
    if (!c) {
      showMessage('Type a city name');
      return;
    }
    state.city = c;
    fetchWeather(c);
  });

  el.locBtn.addEventListener('click', () => {
    if (!navigator.geolocation) return showMessage('Geolocation not supported');
    navigator.geolocation.getCurrentPosition(async pos => {
      const { latitude: lat, longitude: lon } = pos.coords;
      showMessage('Loading location weather...');
      try {
        // call backend by coords if supported, else perform a reverse lookup via backend route /weather?lat=..&lon=..
        const res = await fetch(`${API_BASE}/weather?lat=${lat}&lon=${lon}`);
        const json = await res.json();
        if (!res.ok) throw new Error(json.error || res.statusText);
        const cityName = json.city || json.name;
        el.input.value = cityName || `${lat.toFixed(2)},${lon.toFixed(2)}`;
        fetchWeather(el.input.value);
      } catch (err) {
        showMessage('Error getting location weather');
        console.error(err);
      }
    }, err => showMessage('Location error: ' + err.message));
  });

  // Auto load a sample city
  window.addEventListener('load', () => {
    const urlCity = new URLSearchParams(window.location.search).get('city');
    const initial = urlCity || 'Hyderabad';
    el.input.value = initial;
    fetchWeather(initial);
  });

})();