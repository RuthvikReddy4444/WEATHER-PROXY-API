// backend/index.js (replace /weather handler with this implementation)
require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');

const app = express();
app.use(cors());

const API_KEY = process.env.KEY || process.env.OPENWEATHER_API_KEY;

app.get('/weather', async (req, res) => {
  try {
    const { city, lat, lon } = req.query;
    const params = { appid: API_KEY, units: 'metric' };
    if (city) params.q = city;
    else if (lat && lon) {
      params.lat = lat;
      params.lon = lon;
    } else {
      return res.status(400).json({ error: 'Provide city or lat+lon' });
    }

    const r = await axios.get('https://api.openweathermap.org/data/2.5/weather', { params });
    const d = r.data;

    // Map only the fields frontend expects
    const out = {
      city: d.name,
      country: d.sys?.country,
      temperature_celsius: d.main?.temp,
      feels_like: d.main?.feels_like,
      temp_min: d.main?.temp_min,
      temp_max: d.main?.temp_max,
      pressure: d.main?.pressure,
      humidity: d.main?.humidity,
      visibility: d.visibility,
      clouds: d.clouds?.all,
      wind_speed: d.wind?.speed,
      wind_deg: d.wind?.deg,
      weather: d.weather?.[0]?.description,
      icon: d.weather?.[0]?.icon,
      sunrise: d.sys?.sunrise,
      sunset: d.sys?.sunset,
      timezone: d.timezone
    };

    res.json(out);
  } catch (err) {
    console.error(err?.response?.data || err.message);
    res.status(500).json({ error: 'Failed to fetch weather' });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log('API running on', PORT));