
WEATHER PROJECT (Frontend + Backend)

RUN BACKEND:
cd backend
npm install
npm start

RUN FRONTEND:
Open frontend/index.html in browser
