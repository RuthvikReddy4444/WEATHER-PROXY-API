import os, zipfile, shutil
from pathlib import Path

root = Path("weather_full_project")

if root.exists():
    shutil.rmtree(root)
root.mkdir()

# ---------------------------
# FRONTEND
# ---------------------------
frontend = root / "frontend"
frontend.mkdir()

(frontend/"index.html").write_text("""
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Weather App</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<main class="app">
<h1 class="title">Weather App</h1>
<div class="card">
<form id="searchForm" class="search">
<input id="cityInput" placeholder="Enter city...">
<button type="submit">Search</button>
</form>
<div id="message" class="message"></div>
<div id="result" class="result hidden">
<div class="city" id="city"></div>
<div class="desc" id="weatherDesc"></div>
<div class="temp" id="temp"></div>
<div class="details">
Humidity: <span id="humidity"></span><br>
Wind: <span id="wind"></span>
</div>
</div>
</div>
<script src="app.js"></script>
</main>
</body>
</html>
""")

(frontend/"style.css").write_text("""
body{background:#0f1724;color:white;font-family:Arial;padding:20px;}
.app{max-width:400px;margin:auto;}
.title{text-align:center;margin-bottom:20px;color:#60a5fa;font-size:26px;}
.card{background:#0b1220;padding:20px;border-radius:10px;}
.search{display:flex;gap:10px;margin-bottom:10px;}
.search input{flex:1;padding:10px;border-radius:6px;border:none;}
.search button{padding:10px;background:#60a5fa;color:black;border:none;border-radius:6px;font-weight:bold;}
.result.hidden{display:none;}
.temp{font-size:30px;color:#60a5fa;margin:10px 0;}
.message{margin-top:10px;color:#aaa;}
""")

(frontend/"app.js").write_text("""
(function(){
const api = "http://localhost:3001";
const q = s => document.querySelector(s);

async function getWeather(city){
  q("#message").textContent = "Loading...";
  q("#result").classList.add("hidden");

  try{
    const r = await fetch(api + "/weather?city=" + city);
    const d = await r.json();
    if(!r.ok) throw new Error(d.error);
    q("#city").textContent = d.city;
    q("#weatherDesc").textContent = d.weather;
    q("#temp").textContent = d.temperature_celsius + " °C";
    q("#humidity").textContent = d.humidity;
    q("#wind").textContent = d.wind_speed;
    q("#result").classList.remove("hidden");
    q("#message").textContent = "";
  }catch(e){
    q("#message").textContent = "Error: " + e.message;
  }
}

q("#searchForm").addEventListener("submit",e=>{
  e.preventDefault();
  const c = q("#cityInput").value.trim();
  if(!c) return q("#message").textContent = "Enter a city!";
  getWeather(c);
});
})();
""")

# ---------------------------
# BACKEND
# ---------------------------
backend = root/"backend"
backend.mkdir()

(backend/"package.json").write_text("""
{
  "name": "weather-api",
  "version": "1.0.0",
  "main": "index.js",
  "scripts": {"start": "node index.js"},
  "dependencies": {
    "axios": "^1.4.0",
    "cors": "^2.8.5",
    "dotenv": "^16.3.1",
    "express": "^4.18.2"
  }
}
""")

(backend/"index.js").write_text("""
require('dotenv').config();
const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());

app.get("/weather", async (req,res)=>{
  const city = req.query.city;
  try{
    const r = await axios.get("https://api.openweathermap.org/data/2.5/weather",{
      params:{q:city,appid:process.env.KEY,units:"metric"}
    });
    res.json({
      city:r.data.name,
      temperature_celsius:r.data.main.temp,
      humidity:r.data.main.humidity,
      wind_speed:r.data.wind.speed,
      weather:r.data.weather[0].description
    });
  }catch(e){
    res.status(400).json({error:"Invalid city"});
  }
});

app.listen(3001, ()=>console.log("API running on 3001"));
""")

(backend/".env").write_text("KEY=YOUR_API_KEY_HERE")

# ---------------------------
# DOCUMENTATION
# ---------------------------
docs = root/"documentation"
docs.mkdir()

(docs/"README.txt").write_text("""
WEATHER PROJECT (Frontend + Backend)

RUN BACKEND:
cd backend
npm install
npm start

RUN FRONTEND:
Open frontend/index.html in browser
""")

# ---------------------------
# ZIP
# ---------------------------
zip_path = Path("weather_full_project.zip")
if zip_path.exists(): zip_path.unlink()

with zipfile.ZipFile(zip_path, "w") as z:
    for folder,_,files in os.walk(root):
        for f in files:
            full = os.path.join(folder,f)
            z.write(full, os.path.relpath(full, root))

print("ZIP GENERATED: weather_full_project.zip")