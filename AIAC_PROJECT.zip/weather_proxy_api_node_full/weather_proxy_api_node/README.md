# Weather Proxy API (Node.js)

Simple Express API that fetches weather from OpenWeatherMap and returns a clean JSON response.

Commands:
npm install
npm start
npm run dev

Endpoints:
GET /health
GET /weather?city=Hyderabad
