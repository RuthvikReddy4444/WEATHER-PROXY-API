const axios = require('axios');
class WeatherClient {
    constructor(apiKey) { this.apiKey = apiKey; }

    async fetchCurrentWeather(city) {
        try {
            const res = await axios.get("https://api.openweathermap.org/data/2.5/weather", {
                params: { q: city, appid: this.apiKey, units: "metric" }
            });
            return {
                city: res.data.name,
                temperature_celsius: res.data.main.temp,
                humidity: res.data.main.humidity,
                weather: res.data.weather[0].description
            };
        } catch (err) {
            if (err.response && err.response.status === 404) {
                let e = new Error("Invalid city");
                e.isClient = true;
                throw e;
            }
            throw err;
        }
    }
}
module.exports = WeatherClient;
