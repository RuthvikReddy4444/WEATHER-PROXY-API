const express = require('express');
const WeatherClient = require('../weatherClient');
const router = express.Router();

const client = new WeatherClient(process.env.OPENWEATHER_API_KEY);

router.get('/', async (req, res) => {
    const city = req.query.city;
    if (!city) return res.status(400).json({ error: "City required" });

    try {
        const weather = await client.fetchCurrentWeather(city);
        res.json(weather);
    } catch (err) {
        if (err.isClient) return res.status(400).json({ error: err.message });
        res.status(500).json({ error: "Server error" });
    }
});

module.exports = router;
